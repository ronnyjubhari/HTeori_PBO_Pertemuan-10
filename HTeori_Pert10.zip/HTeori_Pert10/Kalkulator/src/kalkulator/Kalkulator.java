/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
/**
 *
 * @author RECKY
 */
public class Kalkulator extends JFrame {
    
    JTextField txtinput = new JTextField("");
    JButton Btn1 = new JButton("1");
    JButton Btn2 = new JButton("2");
    JButton Btn3 = new JButton("3");
    JButton Btn4 = new JButton("4");
    JButton Btn5 = new JButton("5");
    JButton Btn6 = new JButton("6");
    JButton Btn7 = new JButton("7");
    JButton Btn8 = new JButton("8");
    JButton Btn9 = new JButton("9");
    JButton BtnNol = new JButton("0");
    JButton BtnTitik = new JButton(".");
    JButton BtnCE = new JButton("CE");
    
    /**
     * @param args the command line arguments
     */
    public Kalkulator() {
        super("Kalkulator");
        setSize(300,250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pane = new JPanel();
        GridLayout tampilGrid = new GridLayout(4, 4, 0, 0);
        pane.setLayout(tampilGrid);
        pane.add(Btn1); pane.add(Btn2); pane.add(Btn3);
        pane.add(Btn4); pane.add(Btn5); pane.add(Btn6);
        pane.add(Btn7); pane.add(Btn8); pane.add(Btn9);
        pane.add(BtnNol); pane.add(BtnTitik); pane.add(BtnCE);
        setLayout(new BorderLayout());
        add(txtinput, BorderLayout.NORTH);
        add(add(pane), BorderLayout.CENTER);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Kalkulator kalku = new Kalkulator();
    }
    
}
